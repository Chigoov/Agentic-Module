---
name: autonomi-agentic-ilmiah
description: Portable agent protocol and operational workflow for AUTONOMI AGENTIC ILMIAH (AAI). Guides AI agents across any environment (Kiro IDE, Antigravity, Claude, Codex, GPT) to plan, verify, audit, and generate evidence-controlled academic writing without fabricating sources, citations, or data.
metadata:
  short-description: Evidence-controlled academic research and writing protocol (AAI)
---

# AUTONOMI AGENTIC ILMIAH (AAI) — Portable Agent Protocol

Protokol operasional ini memandu agen AI (Kiro IDE, Antigravity, Claude, Codex, GPT, atau model lainnya) untuk mengoperasikan repositori **AUTONOMI AGENTIC ILMIAH (AAI)** secara aman, deterministik, dan berintegritas akademik tinggi.

**Baca [kontrak input bersama](references/input-json.md) sebelum menyusun payload.**
Kontrak ini mencakup verification_artifact, retrieval/hash, examination,
eligibility_review, assessment berlokasi, kebijakan akses proyek, workbook,
quality gate, status hasil, resume, serta ekspor berdasarkan run_id.
[Contoh sintetis](references/input-synthetic.json) valid menurut skema aktual,
tetapi sengaja belum layak final dan bukan hasil provider/penelitian nyata.

---

## 1. Identitas & Pemicu Penggunaan Skill (Triggers)

* **Singkatan Resmi:** **AAI** = **AUTONOMI AGENTIC ILMIAH**.
* **Kapan Skill Ini Digunakan:**
  Aktifkan protokol ini setiap kali pengguna meminta:
  - *"gunakan AAI"*, *"pakai skill aai"*, *"jalankan autonomi agentic ilmiah"*;
  - pembuatan naskah karya ilmiah / riset berbasis bukti nyata (*evidence-controlled academic writing*);
  - penelusuran pustaka, verifikasi sitasi APA 7, audit fakta, dan pembuatan draf serta dokumen `.docx` akademik anti-halusinasi.

---

## 2. Pemisahan Peran Arsitektur

Agar sistem berjalan portabel di berbagai environment agen, bedakan secara tegas peran lima komponen utama:

1. **Skill (Protokol Workflow & Instruksi Kognitif):**
   Panduan aturan etika riset, alur kerja, validasi integritas data, dan heuristik penalaran yang wajib ditaati oleh agen AI. Skill **bukan mesin eksekusi** dan **bukan model runtime**.
2. **Repositori Python (Mesin Eksekusi Deterministik):**
   Kumpulan modul Python di folder `DATA BASE` (`src/`) yang mengeksekusi pemeriksaan skema (Pydantic), gate integritas akademik (`gates.py`), audit sitasi dan fakta (`audit.py`), kompilasi dokumen Word (`docx_generator.py`), pelacakan jejak run (`audit_trail.py`), serta pengemasan berkas (`export_bundle.py`).
3. **Model Provider (Komponen Opsional):**
   Penyedia inferensi LLM tambahan (seperti model lokal Ollama, vLLM, atau API eksternal). Model provider **bersifat opsional**; engine inti repositori bekerja secara deterministik tanpa mewajibkan OpenRouter atau penyedia komersial tertentu.
4. **Internet Search (Komponen Agen untuk Verifikasi Sumber):**
   Kemampuan web search / API query (Crossref, PubMed, Semantic Scholar, dsb.) milik agen AI untuk memverifikasi keberadaan publikasi nyata, mencocokkan DOI resmi, mengecek nomor volume/isu/halaman, dan memastikan kutipan bukan rekayasa.
5. **Sandbox & Terminal (Lingkungan Eksekusi):**
   Environment eksekusi lokal tempat agen dapat menjalankan perintah launcher lokal (`.\aai.bat ...` atau `python -m src ...`) dan memeriksa luaran berkas proyek (`draft.md`, `final.docx`, `runs/`, `exports/`).

---

## 3. Protokol Kerja 6 Langkah AI Agent

Ketika agen AI ditugaskan menyusun naskah akademik dengan AAI, jalankan siklus kerja berikut secara berurutan:

```
+-----------+     +-------------------+     +------------------+
| 1. CHECK  | --> | 2. WEB SEARCH     | --> | 3. COMPOSE JSON  |
| aai check |     | (Cari Sumber Riil)|     | (Skema & Review) |
+-----------+     +-------------------+     +------------------+
                                                      |
                                                      v
+-----------+     +-------------------+     +------------------+
| 6. REVISE | <-- | 5. AUDIT VERIFY   | <-- | 4. RUN AAI       |
| (Perbaiki)|     | (Baca JSON Audit) |     | aai run in.json  |
+-----------+     +-------------------+     +------------------+
```

### Langkah 1: Pemeriksaan Kesiapan Sistem
Sebelum melakukan manipulasi apa pun, agen wajib menjalankan health check sistem:
```powershell
.\aai.bat check
# atau: python -m src check
```
Pastikan kesehatan struktural lulus, lalu periksa kesiapan perintah yang diperlukan.

### Langkah 2: Penelusuran Sumber Ilmiah Nyata (Internet Tool Agen)
Agen diperbolehkan dan **diwajibkan menggunakan tools internet search miliknya sendiri** untuk menelusuri literatur ilmiah asli:
* Cari publikasi bereputasi (Crossref, arXiv, PubMed, Google Scholar, IEEE, Springer, Elsevier).
* Catat secara presisi: Judul lengkap, nama penulis (format APA: `Family, Initials`), tahun terbit, nama jurnal/venue, volume, nomor terbitan, rentang halaman, dan tautan resolusi DOI aktif.
* Ambil teks kutipan asli secara **verbatim** langsung dari abstrak atau teks lengkap artikel.

### Langkah 3: Penyusunan Payload Input JSON
Agen menyusun berkas input JSON (misal `input_project.json`) sesuai skema Pydantic:
* `sources`: Sumber ilmiah yang ditemukan dengan status deklarasi awal yang jujur (gunakan `DOI_VERIFIED` atau `DISCOVERED`).
* `claims`: Proposisi klaim ilmiah yang ingin diajukan.
* `evidence`: Bukti empiris pendukung. Untuk klaim konsekuensial (kausal, statistik, efektivitas, arah, mekanisme, absolut), **wajib menyertakan bukti verbatim dari abstract atau full text** (`extraction_method: "VERBATIM_ABSTRACT"` atau `"VERBATIM_FULLTEXT"`), bukan hanya parafrase model.
* `outline`: Struktur bab dan subbab naskah yang memetakan claim IDs.
* `semantic_reviews`: Catatan ulasan kesesuaian makna semantik antara klaim dan bukti:
  - Wajib menyertakan 7 atribut lengkap: `claim_id`, `decision: "SUPPORTED"`, `reason`, `evidence_id`, `source_id`, `evidence_excerpt`, `location`, `reviewer`, `method`.
  - `evidence_excerpt` wajib merupakan bagian kontigu utuh (*exact contiguous substring*) dari teks bukti asli.

### Langkah 4: Eksekusi Alur Penulisan & Verifikasi
Jalankan eksekusi melalui perintah launcher:
```powershell
.\aai.bat run input_project.json
```
Repositori akan secara deterministik menjalankan:
`synthesis` ➔ `outline` ➔ `writing` ➔ `humanizer` ➔ `citation_audit` ➔ `fact_audit` ➔ `docx_generation`.

### Langkah 5: Pembacaan Wajib Audit Sitasi, Audit Fakta, & Run Trail
Agen **DILARANG menyatakan tugas berhasil sebelum memeriksa berkas audit**:
1. Buka dan baca `citation_audit.json`:
   - Pastikan `"passed": true`.
   - Pastikan `"orphan_citations": []`, `"internal_tokens": []`, `"author_year_orphans": []`.
2. Buka dan baca `fact_audit.json`:
   - Pastikan `"passed": true`, `"structural_passed": true`, `"semantic_passed": true`.
   - Pastikan `"unsupported_claims": []` dan `"rejection_reasons": []`.
3. Buka dan baca `human_style_audit.json` (Guard Output Manusia/Mahasiswa):
   - Pastikan `"passed": true`.
   - Pastikan bebas dari penambahan bab tak diminta, frasa klise AI, dan tabel/spreadsheet yang terlalu rumit.
4. Periksa keberadaan naskah final:
   - Baca metadata `execution_success`, `result_status`, `finalization_allowed`,
     `needs_human_review`, serta `runs/<run_id>/run_summary.json` aktual.
   - `final.docx` hanya dibuat jika audit, quality gate, workbook/scoring dan
     review queue memenuhi finalisasi. PARTIAL dapat disimpan dan diekspor.
   - Periksa draf `draft.md` bebas dari segala token internal (`turn...`, `view...`, `search...`, `filecite`, atau `【...】`).

### Langkah 6: Tindakan Perbaikan jika Audit Gagal (Looping & Refinement)
Jika audit gagal (`passed: false` atau muncul alasan penolakan pada `fact_audit.json`):
* **DILARANG KERAS mengarang hasil, memalsukan persetujuan, atau mengubah draf manual secara sepihak.**
* Agen wajib membaca `rejection_reasons` pada laporan audit, memperbaiki cacat pada berkas input JSON (misalnya: mencari kutipan verbatim yang sesuai di teks sumber asli, memperbaiki ketidaksesuaian ID rantai bukti, melengkapi parameter ulasan semantik yang hilang, atau menambahkan *qualifier* pada klaim yang terlalu kuat/overclaiming).
* Revisi memakai project/path aktual dari response dan `--resume`, sehingga run
  baru berada pada project yang sama. Periksa claim_screening dan revisi outline
  bila dukungan hilang; jangan menghapus klaim penting agar audit tampak lulus.

---

## 4. Perintah Cepat Launcher `aai`

Pengguna dan AI agent dapat menggunakan shortcut launcher `.\aai.bat` (atau `./aai.ps1`) di root repositori:

| Perintah | Fungsi Utama | Perintah Asli Python |
|---|---|---|
| `.\aai.bat check` | Memeriksa kesiapan sistem repositori | `python -m src check` |
| `.\aai.bat open` | Membuka monitor progress live di browser (port 8000) | Menjalankan server & buka browser |
| `.\aai.bat monitor` | Menjalankan server monitor di terminal | `python -m src monitor --port 8000` |
| `.\aai.bat run <file.json>` | Menjalankan alur penulisan akademik lengkap | `python -m src run-academic --input-json <file>` |
| `.\aai.bat runs <file.json>` | Memeriksa riwayat audit trail eksekusi | `python -m src runs --input-json <file>` |
| `.\aai.bat bundle <file.json>` | Mengekspor arsip paket run mandiri (.zip) | `python -m src export-bundle --input-json <file>` |
| `.\aai.bat help` | Menampilkan panduan ringkas bantuan | - |

---

## 5. Aturan Mutlak Integritas Akademik (Anti-Halusinasi)

1. **Anti-Fabrikasi Sumber & DOI:**
   - Dilarang mengarang nama penulis, tahun terbit, nama jurnal, volume, nomor terbitan, maupun rentang halaman.
   - Dilarang mengarang atau menebak format DOI (seperti `10.9999/...`).
2. **Status Sumber Tidak Boleh Dikarang:**
   - Flag `"state": "APPROVED"` tidak dipercaya sebagai bukti. Snapshot engine
     boleh digunakan kembali bila identitas dan hash valid; pencarian internet
     baru diperlukan ketika bukti tersimpan belum sah atau tidak tersedia.
3. **Kewajiban Bukti Verbatim untuk Klaim Konsekuensial:**
   - Klaim kausal, statistik/numerik, efektivitas, arah, mekanisme, atau kata absolut tidak boleh hanya berlandaskan `MODEL_PARAPHRASE`. Wajib ada kutipan verbatim dari abstrak atau naskah lengkap sumber.
4. **Pembersihan Token Internal AI:**
   - Teks naskah final **DILARANG memuat token:** `turn...`, `view...`, `search...`, `filecite`, `citeturn`, atau kurung mentah `【...】`.
5. **Sitasi & Daftar Pustaka APA 7:**
   - Titik akhir kalimat diletakkan setelah kurung sitasi: `... adaptasi individu (Amato, 2000).`
   - Daftar pustaka wajib memuat nama jurnal, volume, nomor, halaman, dan tautan resolusi DOI aktif.

---

## 6. Humanizer, Tata Letak Dokumen Normal, & Output Guard

Humanizer dan kebijakan `human-doc-output-guard` dijalankan sebelum dokumen final (`draft.md` dan `final.docx`) diekspor. Tujuannya membuat naskah terasa seperti tulisan mahasiswa yang rapi, natural, dan berbobot tanpa bloat artifisial AI. Guard ini **tidak boleh** menambah fakta, data, kutipan, DOI, halaman, sumber, atau klaim baru.

Aturan gaya & output guard (lihat `skills/human-doc-output-guard/SKILL.md`):
* Gunakan bahasa Indonesia yang sederhana, natural, dan akademik secukupnya.
* Hindari frasa klise AI: "secara komprehensif", "dalam konteks ini", "penting untuk digarisbawahi", "berdasarkan uraian di atas", "memiliki peran yang sangat signifikan", atau pembuka klise "di era globalisasi".
* Ikuti instruksi pengguna secara sempit: jangan menambah subbab, teori pembuka, lembar cover, atau dekorasi yang tidak diminta.
* Pakai kalimat sedang-pendek bervariasi. Jangan memaksa semua paragraf terdengar formal atau bombastis.
* Pertahankan penanda jujur seperti `[perlu data pendukung]` dan `[sumber belum lengkap]`.

Aturan tabel, daftar, dan heading:
* Tabel dipakai hanya untuk data, perbandingan, rubrik, jadwal, atau ringkasan yang memang lebih mudah dibaca dalam kolom.
* Tabel normal mahasiswa biasanya ringkas: 2-4 kolom, judul kolom jelas, isi sel pendek, dan tidak berisi paragraf panjang.
* Jangan membuat tabel hanya agar dokumen terlihat ramai. Jika satu paragraf lebih jelas, gunakan paragraf.
* Bullet/nomor dipakai hanya untuk daftar nyata. Jangan mengubah seluruh esai menjadi poin-poin.
* Heading dibuat singkat dan wajar, misalnya `Pendahuluan`, `Pembahasan`, `Kesimpulan`, bukan heading promosi atau terlalu dramatis.
* Format data spreadsheet (NIM, nomor HP, tanggal, Rupiah) wajib dilindungi dan sel kosong tidak boleh diisi dengan data rekaan.

---

## 7. Batasan Sistem dan Keterbukaan Ilmiah (Honest Reporting)

Setiap tugas AAI menyerahkan dua Excel: workbook temuan sesuai template standar
dan laporan pekerjaan ringkas (tujuan, pekerjaan, hasil, kendala, langkah
berikutnya). Gunakan path aktual pada respons; jelaskan bila file tidak dapat
dibuat. Jika tidak ada artikel, katakan demikian dan jangan mengarang isinya.

* **Jangan Pernah Mengklaim "100% Anti-Halusinasi":**  
  Gunakan bahasa yang presisi dan jujur:
  - *"Empat bypass integritas yang diuji telah tertutup secara deterministik."*
  - *"Sumber dan metadata diverifikasi ulang terhadap basis data bibliografi resmi."*
  - *"Evidence verbatim dicocokkan secara persis dengan abstrak/teks sumber yang tersedia."*
* **Kebutuhan Human-in-the-Loop:**  
  Python Engine memvalidasi integritas mekanis dan tekstual. Namun, evaluasi kesesuaian makna ilmiah yang mendalam (*semantic fit*) atas apakah sebuah premis riset benar-benar memvalidasi kesimpulan tetap mengandalkan agen penalaran AI dan **tetap membutuhkan verifikasi akhir oleh pakar manusia (*human review*)** sebelum naskah dipublikasikan secara akademik.


## Kontrak operasional QC 3 November 2026

- Engine menjalankan validasi deterministik. Agent pengarah menilai relevansi,
  metode, dan makna klaim. ModelRouter dan ContextLoader belum menjadi jalur
  penalaran workflow utama. Provider model opsional. Telemetri engine tidak
  mengukur token/biaya/waktu berpikir agent luar; jangan mengklaim persentase hemat.
- `python -m src check` memeriksa kesehatan struktural. Gunakan
  `python -m src check --for research` (atau `run-academic`, `finalize`, `plan`)
  untuk kesiapan konfigurasi per perintah. Konfigurasi siap bukan integrasi VERIFIED.
- Monitor hanya loopback. `GET /api/check` dan `GET /api/plan` ditolak.
  Gunakan `POST /api/check`, `POST /api/plan`, `POST /api/run-academic` dengan
  header `X-Autonomi-Token` dari instalasi lokal. Jangan menonaktifkan Host/Origin/token.
- Review klaim harus menamai reviewer sebenarnya. Contoh AI:
  `python -m src review-queue <project> --resolve <exact_review_id> --decision SUPPORTED --notes "alasan berdasarkan bukti" --reviewer "nama-agent" --reviewer-type ai`.
  Pakai `human` hanya untuk pemeriksa manusia yang benar-benar melakukan penilaian.
  Jangan menyatakan gelar pakar atau persetujuan manusia tanpa bukti.
- Review JSON eksternal wajib mengisi `input_fingerprint` yang dihitung dengan
  `SemanticReview.fingerprint(claim, evidence, sources)` atas isi yang benar-benar
  dinilai. Nilai ini adalah pengikatan versi, bukan bukti penilaian manusia.
  Review legacy tanpa fingerprint harus dinilai ulang; jangan diisi retroaktif.
- `evidence.jsonl` menyimpan history. `current_evidence.json` menjadi input finalisasi
  terkini; snapshot immutable tiap run tetap tersedia. Revisi isi evidence perlu
  ID baru. Ulang input yang sama tidak menambah baris history.
- `search_options` menerima `queries`, `concepts`, `year_start`, `year_end`,
  `source_types`, `max_results_per_query` (1–200), `target_sources` (1–1000), dan
  `request_budget` (1–100). Crossref mendukung pagination offset sampai anggaran
  habis. Provider lain satu halaman per query. Seluruh kandidat dan alasan filter
  disimpan; lexical ranking bukan persetujuan relevansi ilmiah.
- Kapasitas lokal: dua workflow aktif lintas proses dan 16 request HTTP.
  Deadline kooperatif 900 detik diperiksa saat agent/tool/verifikasi berikutnya
  dimulai. Panggilan yang sedang berjalan tetap memakai timeout tool sendiri.
  Kapasitas penuh ditolak, bukan antrean tak berbatas. Lock proses terputus
  harus diperiksa sebelum pemulihan manual. Belum merupakan bukti soak produksi.


### Koreksi empat temuan review ulang

- Gate dukungan sumber memakai pemetaan alias publikasi yang sama dengan dedupe,
  termasuk record lintas provider tanpa DOI. DOI atau ISBN yang saling bertentangan
  tidak boleh digabung otomatis. Metadata bibliografis yang belum lengkap tetap
  memerlukan pemeriksaan; pencocokan identitas deterministik bukan review ilmiah.
- Konflik evidence ID diperiksa sebelum mengganti berkas input terkini. Penolakan
  revisi mempertahankan input sebelumnya. Revisi sah memakai evidence ID baru dan
  run immutable baru; jangan mengubah isi dengan ID lama untuk membuka blocker.
- Jika `search_options.concepts` diberikan, target discovery menghitung publikasi
  unik yang memuat seluruh konsep pada judul/abstrak (pencocokan literal tanpa
  membedakan huruf besar/kecil). Kandidat lain tetap disimpan untuk screening,
  tetapi tidak membuat target terpenuhi. Sinonim/variasi query harus dinyatakan
  oleh agent pengarah; kecocokan literal bukan persetujuan relevansi ilmiah.
- Tanpa konsep terstruktur, target masih berdasarkan filter tahun/jenis. Review
  kuantitatif memakai target discovery awal sedikitnya 40 kandidat, kecuali
  `target_sources` ditentukan eksplisit. Log menyatakan `target_candidate_count`
  dan `target_criteria`; tetap periksa jumlah sumber yang benar-benar layak.

### Integritas ekspor dan kegagalan awal

- Run baru ditutup dengan `integrity_manifest.json`: daftar berkas relatif,
  ukuran, dan SHA-256 snapshot, sumber tersimpan, laporan, serta ringkasan.
  Ekspor memvalidasi daftar dan hash tersebut sebelum membuat ZIP. Jangan
  mengubah atau menghitung ulang manifest untuk menerima bukti yang berubah.
- Run lama tanpa manifest tidak diberi bukti integritas secara retroaktif.
  Jalankan revisi/resume untuk menghasilkan run baru, lalu ekspor run baru itu.
  Hash lokal mendeteksi perubahan terhadap catatan penutupan; bukan tanda tangan
  independen jika seseorang mengganti berkas dan manifest sekaligus.
- Lokasi artefak relatif terhadap run dipakai saat ekspor, sehingga proyek
  lengkap dapat dipindah tanpa mengakses lokasi lama. Ekspor tidak mengubah
  isi run; checksum ZIP dicatat di manifest terpisah dalam `exports/`.
- Kegagalan snapshot awal mengembalikan `run_id`, `run_dir`, status gagal dan
  kebutuhan review; penanda aktif ditutup. Ringkasan gagal dan workbook dibuat
  bila penyimpanan masih dapat ditulis. Jika penyimpanan terus gagal, respons
  menyebutkan laporan yang tidak dapat disimpan; jangan mengklaim pemulihan
  hard crash atau media rusak telah teruji.
